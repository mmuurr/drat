as_chr1 <-
  splint_simple(\(x) as.character(x)[1])
as_date1 <-
  splint_simple(\(x) lubridate::as_date(x)[1])

as_person.001 <-
  splint_dict(
    splints = dict(
      first_name = as_chr1,
      last_name = as_chr1,
      birthdate = as_date1,
      should_be_null = as_chr1 |> splint_if_missing(NULL, exactly = TRUE),
      mother =
        splint_simple(as_person) |>
        splint_if_missing(NULL, TRUE)
    ),
    klass = "example.person"
  )

as_person.002 <-
  splint_dict(
    splints = dict(
      first_name = as_chr1,
      last_name = as_chr1,
      birthdate = as_date1,
      should_be_null = as_chr1 |> splint_if_missing(NULL, exactly = TRUE),
      mother =
        splint_simple(\(x) as_person(x)) |>
        splint_if_missing_stop()
    ),
    klass = "example.person"
  )



