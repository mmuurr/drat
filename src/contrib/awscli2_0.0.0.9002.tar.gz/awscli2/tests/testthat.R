library(testthat)
library(awscli2)

test_check("awscli2")
