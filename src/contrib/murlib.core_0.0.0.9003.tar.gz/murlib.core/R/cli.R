#' @export
trailing_args <- function() {
  commandArgs(trailingOnly = TRUE)
}
