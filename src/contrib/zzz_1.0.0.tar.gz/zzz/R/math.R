logit <- function(p) qlogis(p)
