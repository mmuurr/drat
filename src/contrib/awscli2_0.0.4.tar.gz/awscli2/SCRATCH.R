awscli(
  c("elbv2", "describe-load-balancers"),
  "--names" = c("qhol-play", "qhol-play-a")
)

.config <- list(
  "output" = "json"
)
commands <- list(
  "elbv2",
  "describe-load-balancers"
)
command_args <- list(
  "--names" = c("qhol-play", "qhol-play-a")
)

args_list <- dots2list(!!!c(.config, commands, command_args))

## force all names to be strings; if missing then use empty string ("").
## prepend double-hyphen ("--") if named and not already starting with "--"
arg_names <-
  list_names(args_list, "") %>%
  stringr::str_trim() %>%
  { dplyr::if_else(. == "" | stringr::str_detect(., "^--"), ., sprintf("--%s", .)) }

arg_values <- 
  args_list %>%
  purrr::map(function(x) {
    (x %||% "") %>%
      as.character() %>%
      stringr::str_trim()
  })

final_args <-
  purrr::map2(arg_names, arg_values, c) %>%
  purrr::flatten_chr() %>%
  purrr::discard(function(x) stringr::str_length(x) == 0)
