#' @export
`%!in%` <- function(l,r) !(l %in% r)

#' @export
`%notin%` <- `%!in%`
