inherits_all <- function(x, klass = character(0)) {
  if (is.null(klass)) klass <- character(0)

  ## v1:
  ##   all(inherits(x, klass, which = TRUE) > 0)
  ## The > 0 portion isn't needed, however, leading to the implemented code below.
  ##
  ## v2:
  ##   isa(x, klass)
  ## This is surprisingly slow, given that it's a base function.
  ## The implementation below is typically 1.5X--2X faster _after_ the initial run.
  ## (The first run of the user-defined function is slow, but then the JIT/runtime cache is activated.)
  all(inherits(x, klass, which = TRUE))
}


## Because consider x <- 1
## class(x) == "integer", but attr(x, "class") is NULL.
## We should preserve the NULLness, I think.
## The class(x) is fallback behavior when the "class" attribute is NULL.
## By assigning a class explicitly, we are bypassing this fallback.
class_attr <- function(x) attr(x, "class", TRUE)


#' @export
prepend_class <- function(x, cls = character(0)) {
  structure(x, class = unique(c(cls, class_attr(x))))
}


#' @export
append_class <- function(x, cls = character(0)) {
  structure(x, class = unique(c(class_attr(x), cls)))
}
