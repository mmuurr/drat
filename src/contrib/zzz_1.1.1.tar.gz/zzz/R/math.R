#' @title Logistic function.
logit <- qlogis  ## a function
