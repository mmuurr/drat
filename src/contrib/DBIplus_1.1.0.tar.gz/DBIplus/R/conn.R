dbconn_summary_string <- function(dbconn) {
    with(DBI::dbGetInfo(dbconn), sprintf("%s@%s:%s/%s", user, host, port, dbname))
}


try_dbDisconnect <- function(dbconn) {
    try(flog.debug("disconnecting from %s", dbconn_summary_string(dbconn)))
    try(DBI::dbDisconnect(dbconn))
}


dbconn_env <- function() {
    env <- new.env(parent = emptyenv())

    reg.finalizer(env, function(env) {
        lapply(unique(as.list(env)), try_dbDisconnect)
    }, onexit = TRUE)

    return(env)
}


dbconn_env_add <- function(env, ...) {
    if(!is.environment(env)) {
        stop("env must be an environment")
    }

    l <- list(...)

    if(is.null(names(l))) {
        stop("... args must be named")
    }

    if(any(duplicated(names(l)))) {
        stop("... names must be unique")
    }

    if(any(names(l) == "")) {
        stop("... names must be non-empty strings")
    }

    if(!all(purrr::map_lgl(l, inherits, "DBIConnection"))) {
        stop("... args must all be DBIConnection(s)")
    }

    purrr::walk2(names(l), l, assign, pos = env)
    return(env)
}


dbconn_env_str <- function(env, .as_string = FALSE) {
    if(.as_string) {
        zzz::sstr(as.list(env))
    } else {
        str(as.list(env))
    }
}
