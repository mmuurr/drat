#' @importFrom dplyr mutate across
#' @importFrom magrittr %>%
NULL

format_keep_na <- function(f) {
  force(f)
  function(x, ...) {
    na_lix <- is.na(x)
    retval <- f(x, ...)
    retval[na_lix] <- NA  ## type-coercion
    retval
  }
}


format_datetime <- format_keep_na(function(x, time_tz = NULL, time_tz_offset = TRUE, time_digits = 6) {
    zzz::iso8601(x, what = "datetime", tz = time_tz, tz_offset = time_tz_offset, digits = time_digits)
})


format_date <- format_keep_na(function(x) {
  zzz::iso8601(x, what = "date")
})


format_numeric <- format_keep_na(function(x) {
  format(x, digits = NULL, scientific = FALSE, trim = TRUE, drop0trailing = TRUE)
})


redshift_copy_sql_statement <- function(s3_bucket, s3_key,
                                        iam_role_arn,
                                        schema_name, table_name,
                                        gz = FALSE) {
  gz <- DBI::SQL(if (isTRUE(gz)) "GZIP" else "")
  s3_uri <- glue::glue("s3://{s3_bucket}/{s3_key}")
  glue::glue_sql("
    COPY {`schema_name`}.{`table_name`}
    FROM {s3_uri}
    IAM_ROLE {iam_role_arn}
    FORMAT CSV
      {gz}
      EMPTYASNULL
      ENCODING UTF8
      IGNOREBLANKLINES
      IGNOREHEADER 1
      TIMEFORMAT 'auto'
    COMPUPDATE TRUE
    MAXERROR 0
    --NOLOAD --- dry-run
    --STATUPDATE TRUE --- must be table owner to ANALYZE
  ", .con = DBI::ANSI())
}


redshift_exec_copy <- function(redshift_conn,
                               s3_bucket, s3_key,
                               iam_role_arn,
                               schema_name, table_name,
                               gz = FALSE) {
  DBI::dbExecute(redshift_conn, redshift_copy_sql_statement(s3_bucket, s3_key, iam_role_arn, schema_name, table_name, gz))
}


#' @export
s3copy <- function(tbl,
                   redshift_conn,
                   schema_name, table_name,
                   iam_role_arn,
                   s3_bucket, s3_key, s3_delete_on_success = TRUE,
                   time_tz = NULL, time_tz_offset = TRUE, time_digits = 6,
                   gz = TRUE,
                   .aws_profile = NULL) {
  gz <- isTRUE(gz)
  local_filepath <- if (gz) tempfile(fileext = ".gz") else tempfile()

  tbl <- tbl %>%
    mutate(across(where(lubridate::is.POSIXt), format_datetime)) %>%
    mutate(across(where(lubridate::is.Date), format_date)) %>%
    mutate(across(where(is.numeric), format_numeric))

  aws_profile_arg <- list(profile = .aws_profile) %>% purrr::compact()

  s3io::s3io_write(tbl, s3_bucket, s3_key, readr::write_csv, na = "", .localfile = local_filepath, .put_object_args = aws_profile_arg)

  retval <- redshift_exec_copy(redshift_conn, s3_bucket, s3_key, iam_role_arn, schema_name, table_name, gz)

  if (isTRUE(s3_delete_on_success)) do.call(awscli::s3api_delete_object, c(list(s3_bucket, s3_key), aws_profile_arg))

  retval
}
