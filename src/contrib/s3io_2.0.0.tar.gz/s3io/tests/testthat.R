library(testthat)
library(s3io)

test_check("s3io")
