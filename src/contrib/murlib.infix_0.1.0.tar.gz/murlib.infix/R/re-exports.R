#' @export
`%@%` <- rlang::`%@%`

#' @export
`%@%<-` <- rlang::`%@%<-`

#' @export
`%||%` <- rlang::`%||%`

#' @export
`%|%` <- rlang::`%|%`

#' @export
`%0%` <- vctrs::`%0%`

#' @export
`%===%` <- murlib.core::`%===%`

#' @export
`%!in%` <- murlib.core::`%!in%`

#' @export
`%notin%` <- murlib.core::`%notin%`
