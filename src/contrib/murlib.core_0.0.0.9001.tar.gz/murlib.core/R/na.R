#' @export
na_lgl     <- NA

#' @export
na_int     <- NA_integer_

#' @export
na_dbl     <- NA_real_

#' @export
na_chr     <- NA_character_

#' @export
na_date    <- as.Date(NA)

#' @export
na_posixct <- as.POSIXct(NA)

