.onAttach <- function(libname, pkgname) {
    options(str = strOptions(strict = "cut"))
}
