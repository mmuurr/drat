logit <- qlogis  ## a function
