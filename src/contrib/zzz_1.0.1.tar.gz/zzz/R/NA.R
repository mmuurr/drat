NA_logical_ <- NA
NA_double_ <- NA_real_

