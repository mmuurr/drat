#' @export
itself <- function(x, ...) {
  if (missing(x)) invisible(NULL) else x
}

