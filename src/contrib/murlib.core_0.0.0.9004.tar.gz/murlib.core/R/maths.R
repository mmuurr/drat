## logistic function (alias)
#' @export
logit <- stats::qlogis
