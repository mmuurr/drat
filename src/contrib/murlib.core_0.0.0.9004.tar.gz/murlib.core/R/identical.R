#' @export
`%===%` <- function(l, r) identical(l, r)
