identity <- function(x, ...) {
  if (missing(x)) NULL else x
}
